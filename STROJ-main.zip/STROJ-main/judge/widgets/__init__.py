from judge.widgets.ace import *
from judge.widgets.checkbox import CheckboxSelectMultipleWithSelectAll
from judge.widgets.martor import *
from judge.widgets.mixins import CompressorWidgetMixin
from judge.widgets.select2 import *
