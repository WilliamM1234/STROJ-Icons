"""
Martor originally from https://github.com/agusmakmun/django-markdown-editor
"""

from .widgets import AdminMartorWidget, MartorWidget
